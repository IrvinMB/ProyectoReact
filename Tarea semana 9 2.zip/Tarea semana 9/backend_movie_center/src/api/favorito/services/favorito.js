'use strict';

/**
 * favorito service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::favorito.favorito');
