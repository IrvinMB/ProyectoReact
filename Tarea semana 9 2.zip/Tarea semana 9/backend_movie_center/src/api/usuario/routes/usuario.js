'use strict';

/**
 * usuario router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::usuario.usuario');
