function Favoritos() {
	return <h2>Favoritos</h2>;
}
export default Favoritos;
