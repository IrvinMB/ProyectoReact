function Peliculas() {
    return <h2>Peliculas</h2>;
}
export default Peliculas;