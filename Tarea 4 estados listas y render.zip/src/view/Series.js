function Series() {
	return <h2>Series</h2>;
}
export default Series;
