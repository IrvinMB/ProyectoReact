import React,{useState} from 'react';
import Favorito from '../components/favorito'; 
function Favoritos() {
	return <Favorito/>;
}
export default Favoritos;
