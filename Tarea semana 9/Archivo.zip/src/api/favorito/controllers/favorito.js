'use strict';

/**
 * favorito controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::favorito.favorito');
